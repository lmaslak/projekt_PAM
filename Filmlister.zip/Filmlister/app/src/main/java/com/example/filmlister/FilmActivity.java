package com.example.filmlister;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class FilmActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_film);
        AppRoomDatabase appRoomDatabase;
        FilmDao filmDao;
        appRoomDatabase = AppRoomDatabase.getAppRoomDatabase(getApplicationContext());
        filmDao = appRoomDatabase.filmDao();


        Button bSave = findViewById(R.id.film_save);
        EditText etTitle = findViewById(R.id.film_title);
        EditText etDirector = findViewById(R.id.film_director);
        EditText etLength = findViewById(R.id.film_length);

        bSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = "", director = "";
                int length = 0;

                title = etTitle.getText().toString();
                director = etDirector.getText().toString();
                try {
                    lenghts = Integer.parseInt(etLength.getText().toString());
                } catch (Exception ignored) {
                }

                if (!title.isEmpty()) {
                    String finalTitle = title;
                    String finalDirector = director;
                    int finalLength = length;
                    AppRoomDatabase.databaseWriterExecutor.execute(() -> filmDao.insertFilm(new Film(finalTitle, finalDirector, finalLength)));
                    finish();
                }

            }
        });
    }
}
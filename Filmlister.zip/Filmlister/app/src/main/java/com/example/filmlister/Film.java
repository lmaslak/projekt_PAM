package com.example.filmlister;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "film_table")
public class Film {
    @PrimaryKey(autoGenerate = true)
    public int uid;

    @ColumnInfo(name = "title")
    public String title;

    @ColumnInfo(name = "director")
    public String director;

    @ColumnInfo(name = "length")
    public Integer length;


    public Film(String title, String director, int length) {
        this.title = title;
        this.director = director;
        this.length = length;
    }

    public Film(int id, String title, String director, int length) {
        this.uid = id;
        this.title = title;
        this.director = director;
        this.length = length;
    }

    public Film(int id) {
        this.uid = id;
        this.title = "";
        this.director = "";
        this.length = 0;
    }
}


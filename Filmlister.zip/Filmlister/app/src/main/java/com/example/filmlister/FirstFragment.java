package com.example.filmlister;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.SimpleAdapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;

import com.example.filmlister.databinding.FragmentFirstBinding;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FirstFragment extends Fragment {

    private FragmentFirstBinding binding;
    List<Map<String, String>> maps = new ArrayList<Map<String, String>>();

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentFirstBinding.inflate(inflater, container, false);
        binding.listfilm.setAdapter(buildAdapter());
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        MainActivity.listFilms.observe(getViewLifecycleOwner(), new Observer<List<Film>>() {
            @Override
            public void onChanged(List<Film> film) {
                maps = new ArrayList<Map<String, String>>();
                for (Film b : film) {
                    Map<String, String> temp = new HashMap<>();
                    temp.put("title", b.title);
                    temp.put("director", b.director);
                    temp.put("length", String.valueOf(b.length));
                    temp.put("id", String.valueOf(b.uid));
                    maps.add(temp);
                }
                binding.listfilm.setAdapter(buildAdapter());
            }
        });

        MainActivity.countFilms.observe(getViewLifecycleOwner(), new Observer<Integer>() {
            @Override
            public void onChanged(Integer integer) {
                binding.filmCouter.setText(String.valueOf(integer));
            }
        });
        binding.listfilm.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                adapterView.getItemAtPosition(i);

                Intent intent = new Intent(getContext(),
                        ManageFilm.class);

                intent.putExtra("film", (Serializable) adapterView.getItemAtPosition(i));
                startActivity(intent);

            }
        });
    }


    public ListAdapter buildAdapter() {
        return new SimpleAdapter(getContext(), maps,
                R.layout.list_item,
                new String[]{"title", "director", "length", "uid"},
                new int[]{R.id.item_title, R.id.item_director, R.id.item_length});
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onResume() {
        super.onResume();
        binding.listfilm.setAdapter(buildAdapter());
    }
}
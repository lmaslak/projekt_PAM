package com.example.filmlister;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface FilmDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insertFilm(Film film);

    @Update(onConflict = OnConflictStrategy.IGNORE)
    void updateFilm(Film film);

    @Delete()
    void deleteFilm(Film film);

    @Query("SELECT COUNT(uid) FROM film_table")
    LiveData<Integer> getFilmCount();

    @Query("SELECT * FROM film_table")
    LiveData<List<Film>> getAllFilms();

}
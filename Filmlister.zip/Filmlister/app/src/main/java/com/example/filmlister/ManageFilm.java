package com.example.filmlister;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.HashMap;

public class ManageFilm extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_film);

        HashMap<String, String> film = (HashMap<String, String>) getIntent().getSerializableExtra("film");

        AppRoomDatabase appRoomDatabase;
        FilmDao filmDao;
        appRoomDatabase = AppRoomDatabase.getAppRoomDatabase(getApplicationContext());
        filmDao = appRoomDatabase.filmDao();

        EditText et_title = findViewById(R.id.film_manage_title);
        EditText et_director = findViewById(R.id.film_manage_director);
        EditText et_length = findViewById(R.id.film_manage_length);
        Button bt_update = findViewById(R.id.film_manage_update);
        Button bt_delete = findViewById(R.id.film_manage_delete);

        et_title.setText(film.get("title"));
        et_director.setText(film.get("director"));
        et_length.setText(film.get("length"));

        bt_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = String.valueOf(et_title.getText());
                String director = String.valueOf(et_director.getText());
                int length = Integer.parseInt(String.valueOf(et_length.getText()));
                int id = Integer.parseInt(film.get("id"));
                AppRoomDatabase.databaseWriterExecutor.execute(() -> filmDao.updateFilm(new Film(id, title, director, length)));
                finish();
            }
        });

        bt_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = Integer.parseInt(film.get("id"));
                AppRoomDatabase.databaseWriterExecutor.execute(() -> filmDao.deleteFilm(new Film(id)));
                finish();
            }
        });
    }
}